'''

$ chmod a+x file.py
$ echo $PATH
/usr/local/bin:/usr/bin:/bin:/usr/X11R6/bin:/home/swaroop/bin
#add dir to path
PATH=$PATH:/home/swaroop/mydir
$scrypt_py.py - will be found in PATH and executable

'''