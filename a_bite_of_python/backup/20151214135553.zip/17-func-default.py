def say(message = 'hello', times = 1):
    print(message * times)


say()

say('hososososo', 3)