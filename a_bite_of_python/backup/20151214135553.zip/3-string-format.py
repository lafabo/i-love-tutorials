age=26
name='Boriska'
print('Age {0} -- {1} years'.format(name,age))
print('{0} rode through the {0}!'.format(name))
print('{0:.3}'.format(1/3))
print('{0:_^14}'.format('hello'))
print('{name} - {book}'.format(name='Mr.N', book='Book of N'))