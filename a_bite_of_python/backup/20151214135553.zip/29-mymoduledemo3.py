from mymodule import *

sayhi()
print('Version: ', __version__)


# import only sayhi, __varnames__ not allowed (as i guess)