if __name__ == '__main__':
    print('This program is launched')
else:
    print('This program was imported to other programm')

#try to launch it with command line as $ python3 filename.py
#and with interpreter using import filename (without .py)

