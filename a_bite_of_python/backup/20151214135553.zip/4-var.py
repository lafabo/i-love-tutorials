i = 5
print(i)
i = i + 1; print(i)

s = '''as lot lines
as
you only
can



IMAGE!!!'''

print(s)


print\
    (s*i)