import mymodule

mymodule.sayhi()
print('Version: ', mymodule.__version__)


# importing absolutely all, like Ctrl+C Ctrl-V into this file