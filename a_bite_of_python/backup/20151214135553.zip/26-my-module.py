def sayhi():
    print('Hello, yes this is a dog')


__version__ = '0.1'