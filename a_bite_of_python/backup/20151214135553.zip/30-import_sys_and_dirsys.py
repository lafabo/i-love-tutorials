import sys

print(dir(sys))
print(dir())
print('a = 5')
a = 5
print(dir())
print('del a')
del a
print(dir())
print(dir())
print(dir(print()))
print(dir(str))


#dir() is awesome