#постусловие
while True:
    s = input('Enter something ("exit" to exit): ')
    if s == 'exit':
        break
    print('Len of string ', s, len(s))
print('exit')