def sayhello():
    print('hello')

sayhello()