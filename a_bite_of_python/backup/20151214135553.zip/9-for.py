#interval: 1 2 3 4. NOT LAST NUM!
for i in range(1,5):
    print(i)
else:
    print('The end of the cycle')

print(list(range(1,5)))