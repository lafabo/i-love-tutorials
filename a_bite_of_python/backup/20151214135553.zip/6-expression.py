length = 5
breadth = 2

area = length * breadth
print('Area square = ', area)
print('Perimeter is ', 2*(length+breadth))

#look how nice Python formated result with spaces!