def maximum(x,y):
    if x > y:
        return x
    elif x == y:
        return 'x == y'
    else:
        return y


maximum(1,4)