from mymodule import sayhi, __version__

sayhi()
print('Version: ', __version__)

# importing only variables you need (and __ver.__)